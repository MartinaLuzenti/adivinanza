package Numeros;

import java.util.Random;
import java.util.Scanner;

public class AdivinarNumerocontrolador {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner (System.in);
		int intentos=3;
		int opcionSeleccionada;
		do {
		System.out.println();
		System.out.println("Opción 1: Establecer cantidad de intentos (por defecto 3).");
		System.out.println("Opción 2: Jugar juego.");
		System.out.println("Opción 3: Salir.");
		
		System.out.println("Seleccione una opcion: ");
		
		opcionSeleccionada= scanner.nextInt();
		
		switch (opcionSeleccionada) {
		
		case 1:
			System.out.print("Cantidad de intentos:  ");
			intentos= scanner.nextInt();
			break;
			
		case 2:
			Random rand = new Random();
			
		    int numeroaleatorio1 =rand.nextInt(10); 
		    System.out.println(numeroaleatorio1);
			
		    adivinarNumero juego = new adivinarNumero(numeroaleatorio1,intentos);
			
			System.out.print("Juguemos!");
			
			
			for (int i = intentos; i > 0 ; i--) {
				
			
			
			System.out.print(" Adivina el numero entre 1 y 10 ");
			int adivinanza = scanner.nextInt();

			System.out.println(" El numero que ingreso es:"+  adivinanza);
			
			if (juego.getNumeroaadivinar()  < adivinanza ) {
				System.out.println(" El numero ingresado es mayor al de la adivinanza.Intentalo de nuevo ");
				
				}else if (numeroaleatorio1 == adivinanza ) {
					System.out.println(" Felicitaciones has adivinado el numero");
				}else {
					System.out.println(" El numero ingresado es menor al de la adivinanza.Intentalo de nuevo ");
					}
		
		}
		}
		
	}while (opcionSeleccionada!=3);
		scanner.close();
	}
}


	

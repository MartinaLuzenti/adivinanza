package Numeros;

public class adivinarNumero {
	
	private int numeroaadivinar;
	private int cantidaddeintentos;
	
	public adivinarNumero (int numeroaadivinar,int cantidaddeintentos ) {
		this.numeroaadivinar=numeroaadivinar;
		this.cantidaddeintentos=cantidaddeintentos;
		
		
	}

	public int getNumeroaadivinar() {
		return numeroaadivinar;
	}

	public void setNumeroaadivinar(int numeroaadivinar) {
		this.numeroaadivinar = numeroaadivinar;
	}

	public int getCantidaddeintentosrealizados() {
		return cantidaddeintentos;
	}

	public void setCantidaddeintentos(int cantidaddeintentos) {
		this.cantidaddeintentos = cantidaddeintentos;
	}
	
	

}

package Numeros;

public class Juego {
	 
	public void jugar () {
		adivinarNumero juego = new adivinarNumero(5,3);
		
		
	}
 

}
